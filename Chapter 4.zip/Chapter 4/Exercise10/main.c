#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int i = 6;
    //int j;
    //j = i += i;
    //printf("%d %d", i, j);

    //int i = 5;
    //int j;
    //j = (i -= 2) + 1;
   //printf("%d %d", i, j);

    //int i = 7;
    //int j = 6 + (i = 2.5);
    //printf("%d %d", i, j);

    //int i = 2, j = 8;
    //j = (i = 6) + (j = 3);
    //printf("%d %d", i, j);

    return 0;
}

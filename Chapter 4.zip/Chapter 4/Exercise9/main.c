#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int i = 7, j = 8;
    //i *= j + 1;
    //printf("%d %d", i, j);

    //int i = j = k = 1;
    //i += j += k;
    //printf("%d %d %d", i, j, k);

    //int i = 1, j = 2, k = 3;
    //i -= j += k;
    //printf("%d, %d, %d", i, j, k);

    return 0;
}

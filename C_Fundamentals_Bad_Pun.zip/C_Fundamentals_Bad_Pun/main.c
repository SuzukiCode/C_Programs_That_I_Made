#include <stdio.h>
#include <stdlib.h>

//Author Name: Susan Verdin
//File: C_Fundamentals_Bad_Pun.c
//Purpose prints out a bad pun

int main(void)
{
    printf("To C, or not to C: that is the question.\n");

    int const height = 8;

    return 0;
}

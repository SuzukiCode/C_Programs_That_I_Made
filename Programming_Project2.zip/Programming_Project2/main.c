#include <stdio.h>
#include <stdlib.h>

/*This program takes the radius from a user and
  replaces R with the value in the formula (4/3)(3.14)r^cubed to get the volume*/

  //Author: Susan Verdin
  //File: Programming_Project2.c

int main()
{
    float pi = 3.14;
    int radius;
    float volume;
    int radius_cubed;


    printf("Please enter the radius of a sphere: ");
    scanf(" %d", &radius);

        radius_cubed = radius * radius * radius;

        volume = (4.0f / 3.0f) * pi * radius_cubed;

            printf("\nThe volume of the sphere is: %.1f\n", volume);

    return 0;
}

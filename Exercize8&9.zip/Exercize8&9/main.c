#include <stdio.h>
#include <stdlib.h>

int main()
{
    answer = (3 * q - p * p) / 3;
    return 0;
}

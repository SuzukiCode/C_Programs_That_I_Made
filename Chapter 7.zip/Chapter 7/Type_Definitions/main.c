#include <stdio.h>
#include <stdlib.h>

int main()
{
    typedef int Grades;

    Grades grade1 = 5;

    printf("I received the grade %d\n", grade1);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float dollar;
    float tax = 0.05;
    float tax_amount;
    float final_cost;

    printf("Enter a dollar amount:");
    scanf(" %f", &dollar);

        tax_amount = dollar * tax;
        final_cost = dollar + tax_amount;

            printf("The sales tax is: %.1f", final_cost);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n;

    printf("This program prints the number of squares.\n");
    printf("\nEnter the number of entries in table: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
        printf("%10d%10d\n", i, i * i);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    i = 10;
    for(; i > 0; i--)
        printf("T minus %d and counting\n", i);

    return 0;
}

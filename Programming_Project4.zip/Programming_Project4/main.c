#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    int polyNom;


    printf("Please enter a value for x: ");
    scanf(" %d", &x);

    int five = x * x * x * x * x;
    int four = x * x * x * x;
    int three = x * x * x;
    int x_sqrt = x * x;

    polyNom = ((3 * five + 2 * four) - 5 * three - (x_sqrt + 7 * x) - 6);

    printf("The answer is: %d ", polyNom);
    return 0;
}

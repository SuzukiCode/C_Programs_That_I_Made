#include <stdio.h>
#include <stdlib.h>

int main()
{
    int grade;

    printf("Please rank your grades from 0 - 4 based on how well you've done: ");
    scanf("%d", &grade);

    switch(grade) {
        case 4: printf("\nExcellent\n");
        break;
        case 3: printf("\nGood\n");
        break;
        case 2: printf("\nAverage\n");
        break;
        case 1: printf("\nPoor\n");
        break;
        case 0: printf("\nFailing\n");
        break;
        default: printf("\nIllegal grade\n");
        break;
    }
    return 0;
}

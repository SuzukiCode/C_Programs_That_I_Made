#include <stdio.h>
#include <stdlib.h>

float comissionCalculation(float Value);

int main(void)
{

    float Value = 0;

    printf("Enter value of trade: ");
    scanf("%f", &Value);

    comissionCalculation(Value);

    return 0;
}



float comissionCalculation(float Value)
{

    float commission;

    if(Value < 2500.00f){

        commission = 30.00f + .017f * Value;

    }else if (Value < 6250.00f){

        commission = 56.00f + .0066f * Value;

    }else if (Value < 20000.00f){

        commission = 76.00f + .0034f * Value;

    }else if (Value < 50000.00f){

        commission = 100.00f + .0022f * Value;

    }else if (Value < 500000.00f){

        commission = 155.00f + .0011f * Value;

    }else
        commission = 255.00f + .0009f * Value;


    if (commission < 39.00f){

        commission = 39.00f;

    }

    printf("Commission: $%.2f\n", commission);

    return 0;

}

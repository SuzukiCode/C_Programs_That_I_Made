#include <stdio.h>
#include <stdlib.h>

int main()
{
    int firstGrades;
    float secondGrades;
    int thirdGrades;
    float fourthGrades;

    printf("First Grades: %d\nSecond Grades: %f\nThird Grades: %d\nFourth Grades: %f\n", firstGrades, secondGrades, thirdGrades, fourthGrades);
    return 0;
}

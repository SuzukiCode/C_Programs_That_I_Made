#include <stdio.h>
#include <stdlib.h>

int main()
{
    int prefix = 000;
    int groupID = 0;
    int pubCode = 000;
    int itemNum = 00000;
    int checkDigit = 0;

    printf("Please enter the ISBN (XXX-X-XXX-XXXXX-X): ");
    scanf("%d-%d-%d-%d-%d", &prefix, &groupID, &pubCode, &itemNum, &checkDigit);

    printf("\nGS1 Prefix: %d", prefix);
    printf("\nGroup Identifier: %d", groupID);
    printf("\nPublisher Code: %d", pubCode);
    printf("\nItem Number: %d", itemNum);
    printf("\nCheck Digit: %d\n", checkDigit);
    return 0;
}

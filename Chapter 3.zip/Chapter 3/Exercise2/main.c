#include <stdio.h>
#include <stdlib.h>

int main()
{
    float x = 10.3;
    printf("%d\n", x);

    return 0;
}

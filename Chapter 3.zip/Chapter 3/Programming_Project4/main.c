#include <stdio.h>
#include <stdlib.h>

int main()
{
    int countryCode = 000;
    int num1 = 000;
    int num2 = 0000;
    printf("Enter phone number [(XXX) XXX-XXX]: ");
    scanf("(%d) %d-%d", &countryCode, &num1, &num2);

    printf("You entered: %d.%d.%d", countryCode, num1, num2);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int itemNumber;
    float price;
    int month;
    int day;
    int year;

    printf("Enter item number: ");
    scanf("%d", &itemNumber);

    printf("Enter unit price: ");
    scanf("%f", &price);

    printf("Enter purchase date (mm/dd/yyyy): ");
    scanf("%d/%d/%d", &month, &day, &year);

    printf("\nItem\t\tUnit\t\tPurchase\t\t\n");
    printf("\t\tPrice\t\tDate\n");
    printf("%d\t\t$%.2f\t\t0%d/%d/%d\n", itemNumber, price, month, day, year);
    return 0;
}

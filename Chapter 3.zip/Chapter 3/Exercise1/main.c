#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("%-6.2g", .0000009979);
    return 0;
}

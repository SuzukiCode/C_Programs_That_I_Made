#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 123;

    printf("Integer:%d", x);
    return 0;
}

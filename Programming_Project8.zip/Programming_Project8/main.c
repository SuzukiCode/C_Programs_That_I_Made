#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float loanAmount = 0.0f;
    float interestRate = 0.0f;
    float monthlyPayment = 0.0f;


    printf("Please enter the loan amount:");
    scanf(" %f", &loanAmount);

    printf("\nPlease enter the interest rate:");
    scanf(" %f", &interestRate);

    printf("\nPlease enter the monthly payment:");
    scanf(" %f", &monthlyPayment);



    loanAmount = loanAmount - monthlyPayment + (loanAmount * interestRate / 100.0 / 12.0);
    printf("Balance remaining after first payment: %.2f\n", loanAmount);

    loanAmount = loanAmount - monthlyPayment + (loanAmount * interestRate / 100.0 / 12.0);
    printf("Balance remaining after second payment: %.2f\n", loanAmount);

    loanAmount = loanAmount - monthlyPayment + (loanAmount * interestRate / 100.0 / 12.0);
    printf("Balance remaining after third payment: %.2f\n", loanAmount);

    return 0;
}

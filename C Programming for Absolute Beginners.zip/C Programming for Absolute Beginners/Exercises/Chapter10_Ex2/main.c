#include <stdio.h>
#include <stdlib.h>

/* This program also increases a counter from 1 to 5 printing updates. Then it counts back down to 1.
However, it uses compound operators */

int main()
{
    int ctr = 0;

    ctr += 1; //Increases counter to 1
    printf("Counter is at %d.\n", ctr);

    ctr += 1; //Increases counter to 2
    printf("Counter is at %d.\n", ctr);

    ctr += 1; //Increases counter to 3
    printf("Counter is at %d.\n", ctr);

    ctr += 1; //Increases counter to 4
    printf("Counter is at %d.\n", ctr);

    ctr += 1; //Increases counter to 5
    printf("Counter is at %d.\n", ctr);

    ctr -= 1; //Decreases counter to 4
    printf("Counter is at %d.\n", ctr);

    ctr -= 1; //Decreases counter to 3
    printf("Counter is at %d.\n", ctr);

    ctr -= 1; //Decreases counter to 2
    printf("Counter is at %d.\n", ctr);

    ctr -= 1; //Decreases counter to 1
    printf("Counter is at %d.\n", ctr);

    return 0;
}

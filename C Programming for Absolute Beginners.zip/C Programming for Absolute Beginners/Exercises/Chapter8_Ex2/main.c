#include <stdio.h>
#include <stdlib.h>

//The program asks users for data that prints to the screen

int main()
{
    char topping[24];
    int slices;
    int month, day, year;
    float cost;

    //The first scanf will look for a floating-point variable, which is the cost of the pizza.

    printf("How much does pizza cost in your area?\n");
    printf("Please enter as $XX.XXX\n");
    scanf(" $%f", &cost);

    //The pizza topping is a string, so your scanf does not need the ampersand "&"

    printf("What is your favorite one-word pizza topping?\n");
    scanf(" %s", topping);

    printf("How many slices of %s pizza?", topping);
    printf("can you eat in one sitting?\n");
    scanf(" %d", &slices);

    printf("What is today's date (enter it in XX/XX/XX format).\n");
    scanf(" %d/%d/%d", &month, &day, &year);

    printf("\n\nWhy not treat yourself to dinner on %d/%d/%d",
           month, day, year);
    printf("\nand have %d slices of %s pizza!\n", slices, topping);
    printf("It will only cost you $%.2f!\n\n\n", cost);


    return 0;
}

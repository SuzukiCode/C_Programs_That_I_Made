#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("I am learning the %c programming language!\n", 'C');

    printf("I have just completed Chapter %d\n", 2);

    printf("I am %.1f percent ready to move on!\n", 99.9);

    printf("to the next chapter!\n");
    return 0;
}

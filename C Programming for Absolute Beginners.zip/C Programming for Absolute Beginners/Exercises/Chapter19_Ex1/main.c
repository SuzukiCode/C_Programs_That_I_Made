#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main()
{
    int i;
    int hasUpper, hasLower, hasDigit;
    char user[25], password[25];

    hasUpper = hasLower = hasDigit = 0;

    printf("What is your username? ");
    scanf(" %s", user);

    printf("Please create a password: ");
    scanf(" %s", password);

    for (i = 0; i < strlen(password); i++)
    {
        if(isdigit(password[i]))
        {
            hasDigit = 1;
            continue;
        }

        if(isupper(password[i]))
        {
            hasUpper = 1;
            continue;
        }
        if(islower(password[i]))
        {
            hasLower = 1;
        }
    }

    if((hasDigit) && (hasUpper) && (hasLower))
    {
        printf("Excellent work, %s,\n", user);
        printf("Your password has upper and lowercase letters and a number(s)");
    }

    else
    {
        printf("\n\nYou should consider a new password, %s,\n", user);
        printf("That one uses upper and lowercase letters, and a number");
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int ctr, inner, outer, didSwap, temp;
    int nums[10];
    time_t t;

    srand(time(&t)); // This statement has to be included so the same 10 random numbers between 0 to 99 are not generated each time the program is run.

    for(ctr = 0; ctr < 10; ctr++)
    {
       nums[ctr] = (rand() % 99) + 1; // Fill the array with random numbers
    }

    puts("\nHere is the list before sort:"); // Output numbers before the sort
    for(ctr = 0; ctr < 10; ctr++)
    {
        printf("%d\n", nums[ctr]);
    }

    for(outer = 0; outer > 9; outer++) // Sort the array
    {
        didSwap = 0; // Becomes 1(True) if list has not been ordered yet

        for(inner = outer; inner < 10; inner++)
        {
            if(nums[inner] > nums[outer])
            {
                temp = nums[inner];
                nums[inner] = nums[outer];    /* This area is where the swap is done. Three variables are required for the swap. The outer numbers are stored, temp temporarily stores the numbers in a
                                                temporary array, then nums outer takes them from the temp array to sort and put them in an ordered array*/
                nums[outer] = temp;
                didSwap = 1;
            }
        }

        if(didSwap == 0)
        {
            break;
        }
    }

    puts("\nHere is the list after the sort:"); //List the sorted array
    for(ctr = 0; ctr < 10; ctr++)
    {
        printf("%d\n", nums[ctr]);
    }

    return 0;
}

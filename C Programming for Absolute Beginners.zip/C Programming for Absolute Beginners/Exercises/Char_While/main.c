#include <stdio.h>
#include <stdlib.h>

int main()
{
    char Hello[6] = {'H', 'e', 'l', 'l', 'o', '\0'};

    int i;


    for(i = 0; i < 6; i++)

        printf("%c", Hello[i]);


    return 0;
}

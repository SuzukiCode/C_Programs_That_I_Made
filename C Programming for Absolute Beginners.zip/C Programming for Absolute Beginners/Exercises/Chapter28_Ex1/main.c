#include <stdio.h>
#include <stdlib.h>
#include "../Chapter27_Ex1/bookinfo.h"
FILE * fptr;

int main()
{
    int ctr;
    struct bookInfo books[3]; // Array of three structure variables

    //Get the information about each book from the user

    for(ctr = 0; ctr < 3; ctr++)
    {
        printf("What is the name of the book #%d: ", (ctr+1));
        fgets(books[ctr].title, 45, stdin);

        printf("Who is the author: ");
        fgets(books[ctr].author, 45, stdin);

        printf("How much did the book cost: ");
        scanf(" %f", &books[ctr].price);


        printf("How many pages in the book?: ");
        scanf(" %d", &books[ctr].pages);

        getchar();


    }

    //Remember when typing your filename path to double up the backslashes or C will think you are putting in a conversion character

    fptr = fopen("C:\\users\\Suzuki\\Documents\\BookInfo.txt", "w");

    //Test to ensure that the file opened

    if(fptr == 0)
    {
        printf("Error--file could not be opened\n");
        exit(1);
    }

    //Print a header line and then loop through and print the info. Info is printed to a file instead of printing to the screen

    fprintf(fptr, "\nHere is the collection of books: \n");

    for(ctr = 0; ctr < 3; ctr++)
    {
        fprintf(fptr, "#%d: %s by %s", (ctr+1), books[ctr].title, books[ctr].author);
        fprintf(fptr, "\nIt is %d pages and costs $%.2f", books[ctr].pages, books[ctr].price);
        fprintf(fptr, "\n\n");

    }

    fclose(fptr); // Always close files
    return 0;
}

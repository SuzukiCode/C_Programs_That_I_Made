// This header file defines the structure for information about a book

struct bookInfo
{
    char title[40];
    char author[25];
    float price;
    int pages;
};

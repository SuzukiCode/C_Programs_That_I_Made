#include <stdio.h>
#include <stdlib.h>
#include "bookinfo.h"

int main()
{
    int ctr;
    struct bookInfo books[3]; // Array of three structure variables

    //Get the information about each book from the user

    for(ctr = 0; ctr < 3; ctr++)
    {
        printf("What is the name of the book # %d?\n", (ctr+1));
        fgets(books[ctr].title, 45, stdin);
        puts("Who is the author? ");
        fgets(books[ctr].author, 45, stdin);
        puts("How much did the book cost? ");
        scanf(" $%f", &books[ctr].price);
        printf("How many pages in the book? ");
        scanf(" %d", &books[ctr].pages);
        getchar(); //Clears last newline for next loop
    }

    //Print a header line and then loop through and print the info

    printf("\nHere is the collection of books: \n");

    for(ctr = 0; ctr < 3; ctr++)
    {
        printf("#%d: %s by %s", (ctr+1), books[ctr].title, books[ctr].author);
        printf("\nIt is %d pages and costs $%.2f", books[ctr].pages, books[ctr].price);
        printf("\n\n");

    }
    return 0;
}

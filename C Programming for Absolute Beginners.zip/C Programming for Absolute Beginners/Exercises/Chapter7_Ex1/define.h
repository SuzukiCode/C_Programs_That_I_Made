#include <stdio.h>
#include <stdlib.h>

// If you have certain values that will not change(Or rarely change)
// You can set them with the #DEFINE statements, so that you can change them as needed
// If you plan on using them in several programs, you can place them in a header file

#define KIDS 3
#define FAMILY "The Peytons"
#define MORTGAGE_RATE 5.15


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char first[25] = "Susan";
    char last[25] = "Verdin";

    strcat(first, last);

    printf("I am %s\n", first);

    return 0;
}

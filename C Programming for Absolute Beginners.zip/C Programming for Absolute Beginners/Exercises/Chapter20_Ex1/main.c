#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ages[3];
    int i;

    for (i = 0; i < 3; i++){

        printf("What is the age of child #%d? ", i+1);
        scanf(" %d", &ages[i]);
    }
    return 0;
}

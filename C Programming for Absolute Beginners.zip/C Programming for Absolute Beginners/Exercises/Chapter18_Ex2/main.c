#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int i;
    char msg[25];

    for(i = 0; i < 25; i++)
    {
        msg[i] = getchar();

        if (msg[i] == '\n')
        {
            i--;
            break;
        }
    }

    putchar('\n');

    for(; i >= 0; i--)
    {
        putchar(msg[i]);
    }

    putchar('\n');

    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int planets = 8;
    int friends = 6;
    int potterBooks = 7;
    int starWars = 6;
    int months = 12;
    int beatles = 4;
    int avengers = 6;
    int baseball = 9;
    int basketball = 5;
    int football = 11;


    if((friends + beatles >= baseball) && (friends + avengers >= football))
    {
        printf("The cast of Friends and the Beatles could make a basketball team.\n");
        printf("The cast of Friends could also be the Avengers.\n ");
        printf("They could also make a football team.\n");
    }
    else
    {
        printf("My friends can't make a team with any of them.\n");
    }

        if((starWars <= months) || (potterBooks <= months))
        {
            printf("You could read one Harry Potter book in a month, \n");
            printf("and finish them all in less than a year, \n");
            printf("OR you could see one Star Wars movie a month,\n");
            printf("and finish them all in less than a year.\n");
        }
        else
        {
            printf("Neither can happen. You have too many books and movies. There's not enough time!\n");
        }

            if(!(baseball + basketball > football))
            {
                printf("\nThere are fewer baseball and basketball players\n");
            }
            else
            {
                printf("\nThere are more baseball and basketball players\n");
            }




    return 0;
}

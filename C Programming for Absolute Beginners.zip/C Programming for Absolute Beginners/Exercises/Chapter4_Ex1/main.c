#include <stdio.h>
#include <stdlib.h>

//Absolute Beginner's Guide to C: Chapter 4 example 1
//Written by Susan Verdin

int main()
{
    printf("Column A\tColumn B\tColumn C");
    printf("\nMy computer's beep sounds like this: \a!\n");

    printf("\"Letz\bx fix that typo and then show the backslash ");
    printf("character \\\"That's what she said\n");

    return 0;
}

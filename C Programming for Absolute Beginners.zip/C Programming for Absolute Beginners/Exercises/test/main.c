#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nums[6] = {1, 2, 3, 4, 5, 6};
    int target;

    target = nums[2] + nums[5];

    printf("The sum is %d", target);

    return 0;
}
